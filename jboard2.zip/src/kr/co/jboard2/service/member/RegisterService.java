package kr.co.jboard2.service.member;

public class RegistService {

}
