package kr.co.jboard1.dao;

public class SQL {

	// È¸¿ø
	
	
	// °Ô½ÃÆÇ
	public static final String BOARD_COUNT = "SELECT COUNT(*) FROM JB_BOARD";
	public static final String BOARD_LIST  = "SELECT * FROM JB_BOARD ORDER BY seq DESC LIMIT ?, 10";               
	public static final String BOARD_WRITE = "INSERT INTO JB_BOARD SET cate=?, title=?, content=?, uid=?, regip=?, rdate=NOW()";
	public static final String BOARD_VIEW = "SELECT * FROM JB_BOARD WHERE seq=?";
	
}










